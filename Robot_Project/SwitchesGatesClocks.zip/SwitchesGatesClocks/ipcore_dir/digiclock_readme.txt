The following files were generated for 'digiclock' in directory 
C:\FPGA Lab Manual\Experiment 2\SwitchesGatesClocks\ipcore_dir\

digiclock_readme.txt:
   Text file indicating the files generated and how they are used.

digiclock_xmdf.tcl:
   ISE Project Navigator interface file. ISE uses this file to determine
   how the files output by CORE Generator for the core can be integrated
   into your ISE project.

digiclock_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

